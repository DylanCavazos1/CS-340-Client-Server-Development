# animal_shelter.py

from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure
from bson.objectid import ObjectId 
import urllib.parse

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password, host, port, database, collection):
        # connection variables
        USER = urllib.parse.quote_plus(username)
        PASS = urllib.parse.quote_plus(password)
        HOST = host
        PORT = port
        DB = database
        COL = collection
        
        # Initialize Connection
        try:
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}')
            self.database = self.client[DB]
            self.collection = self.database[COL]
            print("Connection to MongoDB successful.")
        except ConnectionFailure as e:
            print(f"Could not connect to MongoDB: {e}")
        except OperationFailure as e:
            print(f"Authentication failed: {e.details}")

    # Create method to implement the C in CRUD        
    def create(self, data):
        if data:
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except Exception as e:
                print(f"An error occurred while inserting data: {e}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")
                                        
    # Read method to implement the R in CRUD    
    def read(self, query=None):
        if query is None:
            query = {}
        try:
            result = self.collection.find(query)
            return list(result)
        except Exception as e:
                print(f"An error occurred while retrieving data: {e}")
                return []
                
    # Update method to implement the U in CRUD
    def update(self, query, new_values):
        if query and new_values:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred while updating data: {e}")
                return 0
        else:
            raise ValueError("Query and new values parameters are required")
            
    # Delete method to implement the D in CRUD
    def delete(self, query):
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred while deleting data: {e}")
                return 0
        else:
            raise ValueError("Query parameter is empty")
